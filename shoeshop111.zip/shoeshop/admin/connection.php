<?php
$dsn="mysql:host=localhost;dbname=shoeshop_db";
$user="root";
$password="";
$pdo=new PDO($dsn,$user,$password);
?>